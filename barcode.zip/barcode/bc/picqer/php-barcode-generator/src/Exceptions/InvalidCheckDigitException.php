<?php

namespace Picqer\Barcode\Exceptions;

class InvalidCheckDigitException extends BarcodeException {}